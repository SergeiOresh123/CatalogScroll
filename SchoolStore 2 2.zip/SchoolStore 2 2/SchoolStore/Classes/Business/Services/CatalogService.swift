//
//  CatalogService.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

protocol CatalogService: AnyObject {
    func getProductList(completion: ((Result<[Product], Error>) -> Void)?)
}

final class CatalogServiceImpl: CatalogService {
    
    init(networkProvider: NetworkProvider) {
        self.networkProvider = networkProvider
    }
    
    typealias catalog = DataResponse<GetListOfProductResponse>
    
   /* func getProductList(completion: ((Result<[Product], Error>) -> Void)?) {
         networkProvider.mock(CatalogRequest.listOfProducts) { (result: Result<DataResponse<[Product]>, Error>) in
            switch result {
            case .success:
                completion?(result.map({obj in obj.data}))
            case .failure:
                completion?(result.map(\.data))
            }
        }
    } */
    func getProductList(completion: ((Result<[Product], Error>) -> Void)?) {
        networkProvider.mock(CatalogRequest.listOfProducts, completion: { (result: Result<catalog, Error>) in
             switch result {
             case .success:
                completion?(result.map({obj in obj.data.products}))
             case let .failure(error):
                 completion?(Result.failure(error))
             }
         })
     }
    
    

    private let networkProvider: NetworkProvider

    
  
}


