//
//  ProductBadge.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

struct ProductBadge: Decodable {
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        value = try container.decode(String.self, forKey: CodingKeys.value)
        color = try container.decode(String.self, forKey: CodingKeys.color)

    }

enum CodingKeys: String, CodingKey {
    case value
    case color
}
    
let value: String
let color: String
    
}
