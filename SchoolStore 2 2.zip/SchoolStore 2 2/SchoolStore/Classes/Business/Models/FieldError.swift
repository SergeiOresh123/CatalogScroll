// \HxH School iOS Pass
// Copyright © 2021 Heads and Hands. All rights reserved.
//

import Foundation

struct FieldError: Decodable {
    let field: String
    let message: String
}
