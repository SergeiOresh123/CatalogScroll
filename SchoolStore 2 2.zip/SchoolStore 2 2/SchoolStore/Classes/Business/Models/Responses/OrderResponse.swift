//
//  OrderResponse.swift
//  SchoolStore
//
//  Created by Heads on 08.10.2021.
//

import Foundation

struct ArrangeOrderResponse: Decodable {
    let order: Order
}

struct GetListOfOrdersResponse: Decodable {
    let orders: [Order]
}
