//
//  ProductVC.swift
//  SchoolStore
//
//  Created by Heads on 15.10.2021.
//

import Foundation
import UIKit
import AutoLayoutSugar

class ProductVC: UIViewController {
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        
        return scrollView
    }()
    
    private lazy var buyNowButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.tintColor = .white
        button.setTitle("Купить сейчас", for: .normal)
        button.backgroundColor = .blue
        button.layer.cornerRadius = 8
        return button
    }()
    
    private lazy var returnButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = UIFont(name: "Roboto", size: 20.0)
        button.setTitle("Назад", for: .normal)
        button.setTitleColor(UIColor(red: 0.0, green: 0.207, blue: 0.58, alpha: 1.0), for: .normal)
        return button
    }()
    
    private let contentView = Content()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(returnButton)
        view.addSubview(scrollView)
        
        scrollView.frame = view.bounds
        scrollView.isScrollEnabled = true
        scrollView.addSubview(contentView)
        self.scrollView.contentSize = CGSize(width:200, height: 1200)
        
        returnButton.top(60).left(20).height(44)
        scrollView.top(to: .bottom(20), of: returnButton).left().right().bottom()
        
        view.addSubview(buyNowButton)
        buyNowButton.left(20).right(20).bottom(50)
        
        scrollView.addSubview(contentView)
        
        returnButton.addTarget(self, action: #selector(BackBtn), for: .touchUpInside)
        
    }
    
    @objc func BackBtn() {
        let alertController = UIAlertController(title: "Вернуться в каталог?", message: nil, preferredStyle: .alert)
         
        let LogOutAction = UIAlertAction(title: "Вернуться", style: .default) { (action) -> Void in
            UIApplication.shared.windows.first(where: { $0.isKeyWindow })?.rootViewController = VCFactory.buildTabBarVC()
            
            }
             
        let CloseAction = UIAlertAction(title: "Отмена", style: .default) { (action) -> Void in
              
            }
           
            alertController.addAction(LogOutAction)
            alertController.addAction(CloseAction)
           
        self.present(alertController, animated: true, completion: nil)
    }
    
}



