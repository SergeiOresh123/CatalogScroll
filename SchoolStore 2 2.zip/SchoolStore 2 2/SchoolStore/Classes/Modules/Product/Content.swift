//
//  Content.swift
//  SchoolStore
//
//  Created by Heads on 18.10.2021.
//

import Foundation
import UIKit
import AutoLayoutSugar

final class Content: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private lazy var contentImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var contentImageView1: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var contentImageView2: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var contentImageView3: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var hitLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var departmentLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var sizeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var descriptionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private lazy var detailInfoLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()
    
    private func setup() {
        self.addSubview(contentImageView)
        self.addSubview(contentImageView1)
        self.addSubview(contentImageView2)
        self.addSubview(contentImageView3)
        self.addSubview(priceLabel)
        self.addSubview(hitLabel)
        self.addSubview(departmentLabel)
        self.addSubview(titleLabel)
        self.addSubview(sizeLabel)
        self.addSubview(descriptionLabel)
        self.addSubview(detailInfoLabel)
        
        contentImageView.top().left(50).right(43.75).width(284).height(284)
        contentImageView1.top(to: .bottom(20), of: contentImageView).left(121.5).width(32).height(32)
        contentImageView2.top(to: .bottom(20), of: contentImageView).left(to: .right(10), of: contentImageView1).width(32).height(32)
        contentImageView3.top(to: .bottom(20), of: contentImageView).left(to: .right(10), of: contentImageView2).width(32).height(32)
        
        let url = URL(string: "https://fanatics.frgimages.com/FFImage/thumb.aspx?i=/productimages/_3533000/ff_3533150-d9254664c08370f8572c_full.jpg&w=340" )
                    let data = try? Data(contentsOf: url!)
        contentImageView.image = UIImage(data: data!)
        contentImageView1.image = UIImage(data: data!)
        contentImageView2.image = UIImage(data: data!)
        contentImageView3.image = UIImage(data: data!)
        
        contentImageView.layer.borderWidth = 2
        contentImageView.layer.borderColor = UIColor.gray.cgColor
        
        contentImageView1.layer.borderWidth = 1
        contentImageView1.layer.borderColor = UIColor.gray.cgColor
        contentImageView2.layer.borderWidth = 1
        contentImageView2.layer.borderColor = UIColor.gray.cgColor
        contentImageView3.layer.borderWidth = 1
        contentImageView3.layer.borderColor = UIColor.gray.cgColor
        
        priceLabel.top(to: .bottom(20), of: contentImageView1).left(20).width(248).height(26)
        priceLabel.font = UIFont(name: "Roboto", size: 24.0)
        priceLabel.textColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        priceLabel.text = "9000 ₽"
        
        hitLabel.top(to: .bottom(20), of: contentImageView1).left(to: .right(1), of: priceLabel).width(99).height(24)
        hitLabel.font = UIFont(name: "Roboto", size: 16.0)
        hitLabel.textAlignment = .center
        hitLabel.textColor = .white
        hitLabel.layer.masksToBounds = true
        hitLabel.backgroundColor = .systemGreen
        hitLabel.layer.cornerRadius = 12
        hitLabel.text = "Хит сезона"
        
        titleLabel.top(to: .bottom(16), of: priceLabel).left(20).width(327).height(72)
        titleLabel.font = UIFont(name: "Roboto", size: 24.0)
        titleLabel.textColor = .black
        titleLabel.text = "Men's Nike J.J. Watt Black Arizona Cardinals Legend Jersey"
        titleLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        titleLabel.numberOfLines = 2
        
        departmentLabel.top(to: .bottom(4), of: titleLabel).left(20).width(73).height(18)
        departmentLabel.font = UIFont(name: "Roboto", size: 16.0)
        departmentLabel.textColor = .gray
        departmentLabel.text = "Джерси"
        
        sizeLabel.top(to: .bottom(16), of: titleLabel).left(20).width(328).height(54)
        sizeLabel.font = UIFont(name: "Roboto", size: 24.0)
        sizeLabel.textColor = .black
        sizeLabel.text = "XXL"
        
        descriptionLabel.top(to: .bottom(16), of: sizeLabel).left(20).width(327)
        descriptionLabel.font = UIFont(name: "Roboto", size: 16.0)
        descriptionLabel.textColor = .black
        descriptionLabel.text = "The Tampa Bay Buccaneers are headed to Super Bowl LV! As a major fan, this is no surprise but it's definitely worth celebrating, especially after the unprecedented 2020 NFL season. Add this Tom Brady Game Jersey to your collection to ensure you're Super Bowl ready. This Nike gear features bold commemorative graphics that will let the Tampa Bay Buccaneers know they have the best fans in the league."
        descriptionLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        descriptionLabel.numberOfLines = 50
        
        detailInfoLabel.top(to: .bottom(16), of: descriptionLabel).left(20).width(327)
        detailInfoLabel.font = UIFont(name: "Roboto", size: 16.0)
        detailInfoLabel.textColor = .gray
        detailInfoLabel.text = """
Material: 100% Polyester
Foam tongue helps reduce lace pressure.
Mesh in the upper provides a breathable and plush sensation that stretches with your foot.
Midfoot webbing delivers security. The webbing tightens around your foot when you lace up, letting you choose your fit and feel.
Nike React foam is lightweight, springy and durable. More foam means better cushioning without the bulk. A Zoom Air unit in the forefoot delivers more bounce with every step. It's top-loaded to be closer to your foot for responsiveness.
The classic fit and feel of the Pegasus is back—with a wider toe box to provide extra room. Seaming on the upper provides a better shape and fit, delivering a fresh take on an icon.
Officially licensed
Imported
Brand: Nike
"""
        detailInfoLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        detailInfoLabel.numberOfLines = 50
  
    }
}
